        <style type="text/css">
            .btn_style:hover{
               background: none !important;
               text-decoration:underline !important;
            }
            
            .link_style:hover{
                color: #FFFFFF !important;
                text-decoration:underline !important;
                }
        </style>
        <footer id="footer" class="p-b-0"> 
            <div class="footer-content" style="background-color:#445058;">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3">
                            <div class="widget">
                                <div style="background-color :#3397D8;width:150px;height:130px;">
                                    <img src="images/disclaimer.jpeg" style="height:80px;width:130px;padding-top:10px;padding-left:13px"/>
                                    <h5 style="font-size:20px;color:white;padding-left:13px">DISCLAIMER</h5>
                                </div>
                                <p class="mt-3" style="color:#98A7B6 ">* We are an independent service provider and are not authorized associate partners from any brands. 
                                Local repair vendors perform all service calls and repairs (note we don’t hold any authorization of ).</p>
                            </div>
                        </div>
                        <div class="col-lg-3 mt-5">
                            <div class="widget">
                                <div style="background-color :#3397D8;width:130px;height:40px;">
                                    <h4 style="color:white;padding-top:5px;padding-bottom:5px;"><i class="fa fa-copyright" aria-hidden="true" style="color:white;padding-left:5px;margin:3px"></i>COPY RIGHT</h4>
                                </div>
                                <p class="mt-5" style="color:#98A7B6 ">All products are trademarks™ or registered® trademarks of their respective holders. Use of them does not imply any affiliation/endorsement by them with us.</p>
                            </div>
                        </div>
                        <div class="col-lg-3 mt-5">
                            <div class="widget">
                                <div style="background-color :#3397D8;width:130px;height:40px;">
                                    <h4 style="color:white;padding-top:5px;padding-bottom:5px;padding-left:10px;">QUICK LINKS</h4>
                                </div>
                                <a href="index.php" class="link_style" style="color:#98A7B6;">Home</a></br>
                                <a href="servicespage.php" class="link_style" style="color:#98A7B6;">Services</a></br>
                                <a href="ac.php" class="link_style" style="color:#98A7B6;">Air-Conditioner Repair Services</a></br>
                                <a href="ref1.php" class="link_style" style="color:#98A7B6;">Refregirator Repair Services</a></br>
                                <a href="washing.php" class="link_style" style="color:#98A7B6;">Washing Machine Repair Services</a></br>
                                <a href="mic wav.php" class="link_style" style="color:#98A7B6;">Microwave Oven Repair Services</a></br>
                                <a href="contact.php" class="link_style"  style="color:#98A7B6;">Contact Us</a></br>
                                <a href="terms.php" class="link_style" style="color:#98A7B6;">Terms & Conditions</a>
                                </div>
                        </div>
                        <div class="col-lg-3 mt-5">
                            <div class="widget">
                                <h4 style="color:white;">Toll Free no.</h4>
                                <div>
                                    <button type="button" class="btn btn_style"style="background-color:#3397D8;">18003092018</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </footer>