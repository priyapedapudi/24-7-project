<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="author" content="INSPIRO" />
    <meta name="description" content="Themeforest Template Polo">
    <!-- Document title -->
    <title>Abyssal Ship Management</title>
    <!-- Stylesheets & Fonts -->
    <link href="css/plugins.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="icon" type="image/jpg" href="images/7.jpg">
    <link href='https://fonts.googleapis.com/css?family=Roboto Slab' rel='stylesheet'>
    <title></title>
    <style type="text/css">
        .inspiro-slider{
            height: 600px !important;
        }
        @media only screen and (min-width: 0px) and (max-width: 520px){
    .inspiro-slider {
    height: 200px !important;
    
}
}
    </style>
</head>
<body>
<?php
include'header.php'
?>        

<div id="slider" class="inspiro-slider slider-fullscreen dots-creative">
            <!-- Slide 1 -->
            <div class="slide" data-bg-image="images/7.jpg">
                
            </div>
            <!-- end: Slide 1 -->
        </div>
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-lg-9">
                        <div class="heading-text heading-section text">
                            <h1  style="color:#3D5084; font-weight: 500; font-size: 30px;">IN-HOUSE TEAM TRAINED TEAM ENSURING SECURITY</h1>
                        </div>
                        <p style="  color: black; font-size:15px;font-weight:400">
                       We are readied specialists whose foundation subtleties are totally checked to ensure your wellbeing and security,Our estimating plans are the best in the market our adjusting charges are clear for our clients from the booking to the culmination of the request, Time is exceptionally valuable and we ensure convenient administrations to our clients.</p>
                      <p style=" color: black; font-size:15px;font-weight:400" > These electrical machines, being made with complex circuits and wiring, require specialized information all together for any fix or upkeep of it. Profiting proficient administrations will accordingly guarantee the effective fix and adjusting of your home machine.</p>
                      </div>
                       <div class="col-lg-3">
                        <div class="sidebar-menu">
                            <ul>
                                <label style="color:#3D5084;">Services</label>
                                         <li ><a href="index.php">Home </a>
                                            </li>
                                           <li ><a href="services.php"> Service</a>
                                              </li>

                                            <li style="padding-left: 15px;"><a href="ac.php">Air Conditioner Repair Service</a>
                                            </li>
                                            </li>
                                            <li style="padding-left: 15px;"><a href="ref1.php">Refregirator Repair Services </a>
                                            </li>
                                            <li style="padding-left: 15px;"><a href="washing.php">Washing Machine Repair Services </a>
                                            </li>
                                            <li style="padding-left: 15px;"><a href="mic wav.php">Microwave Oven Repair Services</a>
                                                 <li ><a href="contact.php">Contact</a>
                                            </li> <li ><a href="terms.php">Terms&Conditions</a>
                                            </li>

                            </ul>
                        </div>
                         
                     </div>
                        
                    </div>
                </div>
                
            </div>
    
    
    
    
        </section>
        <!-- Footer -->
            <<?php include"footer.php" ?>
        <!-- end: Footer -->
     <!-- Scroll top -->
    <a id="scrollTop"><i class="icon-chevron-up"></i><i class="icon-chevron-up"></i></a>
    <!--Plugins-->
    <script src="js/jquery.js"></script>
    <script src="js/plugins.js"></script>
    <!--Template functions-->
    <script src="js/functions.js"></script>        
</body>
</html>
                    
          